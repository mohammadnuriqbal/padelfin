"use client";

import { useState, useEffect, useCallback } from "react";
import { formatCurrency, categoryLabels, paymentMethodLabels } from "@/lib/utils";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend, LineChart, Line, PieChart, Pie, Cell,
} from "recharts";

interface ReportData {
  transactions: Array<{
    id: number;
    type: string;
    category: string;
    description: string;
    amount: string;
    paymentMethod: string;
    transactionDate: string;
    courtNumber: number | null;
    memberName: string | null;
    notes: string | null;
  }>;
  summary: {
    totalIncome: number;
    totalExpense: number;
    netProfit: number;
    count: number;
  };
  period: { startDate: string; endDate: string };
}

const COLORS = ["#10B981", "#3B82F6", "#8B5CF6", "#F59E0B", "#EF4444", "#EC4899", "#06B6D4", "#84CC16"];

export default function ReportsPage() {
  const now = new Date();
  const [startDate, setStartDate] = useState(
    `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`
  );
  const [endDate, setEndDate] = useState(now.toISOString().slice(0, 10));
  const [data, setData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState<"excel" | "pdf" | null>(null);

  const fetchReport = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/report/export?startDate=${startDate}&endDate=${endDate}&format=json`);
      const d = await res.json();
      setData(d);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [startDate, endDate]);

  useEffect(() => {
    fetchReport();
  }, [fetchReport]);

  // Category breakdown chart data
  const categoryData = (() => {
    if (!data) return [];
    const map: Record<string, { name: string; income: number; expense: number }> = {};
    data.transactions.forEach((t) => {
      const label = categoryLabels[t.category] || t.category;
      if (!map[t.category]) map[t.category] = { name: label, income: 0, expense: 0 };
      if (t.type === "income") map[t.category].income += parseFloat(t.amount);
      else map[t.category].expense += parseFloat(t.amount);
    });
    return Object.values(map).filter((d) => d.income > 0 || d.expense > 0);
  })();

  const incomePieData = categoryData.filter((d) => d.income > 0).map((d, i) => ({
    name: d.name, value: d.income, color: COLORS[i % COLORS.length]
  }));

  const expensePieData = categoryData.filter((d) => d.expense > 0).map((d, i) => ({
    name: d.name, value: d.expense, color: COLORS[i % COLORS.length]
  }));

  // Payment method breakdown
  const paymentData = (() => {
    if (!data) return [];
    const map: Record<string, number> = {};
    data.transactions.forEach((t) => {
      const label = paymentMethodLabels[t.paymentMethod] || t.paymentMethod;
      map[label] = (map[label] || 0) + parseFloat(t.amount);
    });
    return Object.entries(map).map(([name, value], i) => ({ name, value, color: COLORS[i % COLORS.length] }));
  })();

  // Daily trend
  const dailyData = (() => {
    if (!data) return [];
    const map: Record<string, { date: string; income: number; expense: number }> = {};
    data.transactions.forEach((t) => {
      const d = t.transactionDate;
      if (!map[d]) map[d] = { date: d, income: 0, expense: 0 };
      if (t.type === "income") map[d].income += parseFloat(t.amount);
      else map[d].expense += parseFloat(t.amount);
    });
    return Object.values(map).sort((a, b) => a.date.localeCompare(b.date));
  })();

  const exportExcel = async () => {
    if (!data) return;
    setExporting("excel");
    try {
      const XLSX = await import("xlsx");
      const wb = XLSX.utils.book_new();

      // Summary sheet
      const summaryData = [
        ["LAPORAN KEUANGAN PADEL"],
        [""],
        ["Periode", `${startDate} s/d ${endDate}`],
        ["Tanggal Cetak", new Date().toLocaleDateString("id-ID")],
        [""],
        ["RINGKASAN"],
        ["Total Pendapatan", data.summary.totalIncome],
        ["Total Pengeluaran", data.summary.totalExpense],
        ["Laba Bersih", data.summary.netProfit],
        ["Margin", data.summary.totalIncome > 0 ? `${((data.summary.netProfit / data.summary.totalIncome) * 100).toFixed(1)}%` : "0%"],
        ["Total Transaksi", data.summary.count],
      ];
      const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
      wsSummary["!cols"] = [{ wch: 25 }, { wch: 20 }];
      XLSX.utils.book_append_sheet(wb, wsSummary, "Ringkasan");

      // Transactions sheet
      const txHeaders = ["No", "Tanggal", "Tipe", "Kategori", "Deskripsi", "Member", "Lapangan", "Metode Bayar", "Jumlah"];
      const txRows = data.transactions.map((t, i) => [
        i + 1,
        t.transactionDate,
        t.type === "income" ? "Pendapatan" : "Pengeluaran",
        categoryLabels[t.category] || t.category,
        t.description,
        t.memberName || "-",
        t.courtNumber ? `Lapangan ${t.courtNumber}` : "-",
        paymentMethodLabels[t.paymentMethod] || t.paymentMethod,
        parseFloat(t.amount),
      ]);
      const wsTransactions = XLSX.utils.aoa_to_sheet([txHeaders, ...txRows]);
      wsTransactions["!cols"] = [
        { wch: 5 }, { wch: 12 }, { wch: 12 }, { wch: 20 },
        { wch: 30 }, { wch: 20 }, { wch: 12 }, { wch: 15 }, { wch: 15 },
      ];
      XLSX.utils.book_append_sheet(wb, wsTransactions, "Transaksi");

      // Category breakdown sheet
      const catHeaders = ["Kategori", "Pendapatan", "Pengeluaran", "Net"];
      const catRows = categoryData.map((c) => [
        c.name, c.income, c.expense, c.income - c.expense,
      ]);
      const wsCat = XLSX.utils.aoa_to_sheet([catHeaders, ...catRows]);
      wsCat["!cols"] = [{ wch: 25 }, { wch: 18 }, { wch: 18 }, { wch: 18 }];
      XLSX.utils.book_append_sheet(wb, wsCat, "Per Kategori");

      XLSX.writeFile(wb, `Laporan_Keuangan_Padel_${startDate}_${endDate}.xlsx`);
    } catch (e) {
      console.error("Export excel error:", e);
    } finally {
      setExporting(null);
    }
  };

  const exportPDF = async () => {
    if (!data) return;
    setExporting("pdf");
    try {
      const jsPDF = (await import("jspdf")).default;
      const autoTable = (await import("jspdf-autotable")).default;

      const doc = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });

      // Header
      doc.setFillColor(16, 185, 129);
      doc.rect(0, 0, 297, 32, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(22);
      doc.setFont("helvetica", "bold");
      doc.text("LAPORAN KEUANGAN PADEL", 14, 14);
      doc.setFontSize(10);
      doc.setFont("helvetica", "normal");
      doc.text(`Periode: ${startDate} s/d ${endDate}   |   Dicetak: ${new Date().toLocaleDateString("id-ID")}`, 14, 24);

      // Summary boxes
      const summaryY = 40;
      const boxes = [
        { label: "Total Pendapatan", value: formatCurrency(data.summary.totalIncome), color: [16, 185, 129] as [number, number, number] },
        { label: "Total Pengeluaran", value: formatCurrency(data.summary.totalExpense), color: [239, 68, 68] as [number, number, number] },
        { label: "Laba Bersih", value: formatCurrency(data.summary.netProfit), color: [59, 130, 246] as [number, number, number] },
        { label: "Total Transaksi", value: `${data.summary.count} transaksi`, color: [139, 92, 246] as [number, number, number] },
      ];

      boxes.forEach((box, i) => {
        const x = 14 + i * 68;
        doc.setFillColor(...box.color);
        doc.roundedRect(x, summaryY, 64, 24, 3, 3, "F");
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(7);
        doc.setFont("helvetica", "normal");
        doc.text(box.label.toUpperCase(), x + 4, summaryY + 9);
        doc.setFontSize(11);
        doc.setFont("helvetica", "bold");
        doc.text(box.value, x + 4, summaryY + 19);
      });

      // Transactions table
      doc.setTextColor(30, 41, 59);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("Detail Transaksi", 14, summaryY + 36);

      const tableData = data.transactions.map((t, i) => [
        i + 1,
        t.transactionDate,
        t.type === "income" ? "Pendapatan" : "Pengeluaran",
        categoryLabels[t.category] || t.category,
        t.description.substring(0, 35),
        t.memberName || "-",
        paymentMethodLabels[t.paymentMethod] || t.paymentMethod,
        formatCurrency(parseFloat(t.amount)),
      ]);

      autoTable(doc, {
        head: [["No", "Tanggal", "Tipe", "Kategori", "Deskripsi", "Member", "Bayar", "Jumlah"]],
        body: tableData,
        startY: summaryY + 40,
        styles: { fontSize: 8, cellPadding: 3 },
        headStyles: { fillColor: [30, 41, 59], textColor: [255, 255, 255], fontStyle: "bold" },
        alternateRowStyles: { fillColor: [248, 250, 252] },
        columnStyles: {
          0: { cellWidth: 8 },
          1: { cellWidth: 24 },
          2: { cellWidth: 24 },
          3: { cellWidth: 35 },
          4: { cellWidth: 60 },
          5: { cellWidth: 30 },
          6: { cellWidth: 20 },
          7: { cellWidth: 30, halign: "right" },
        },
        didParseCell: (hookData) => {
          if (hookData.column.index === 2 && hookData.row.index >= 0 && hookData.section === "body") {
            const val = hookData.cell.text[0];
            if (val === "Pendapatan") {
              hookData.cell.styles.textColor = [16, 185, 129];
              hookData.cell.styles.fontStyle = "bold";
            } else {
              hookData.cell.styles.textColor = [239, 68, 68];
              hookData.cell.styles.fontStyle = "bold";
            }
          }
        },
      });

      // Add new page for category summary
      doc.addPage();
      doc.setFillColor(16, 185, 129);
      doc.rect(0, 0, 297, 16, "F");
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      doc.text("RINGKASAN PER KATEGORI", 14, 11);

      const catTableData = categoryData.map((c) => [
        c.name,
        formatCurrency(c.income),
        formatCurrency(c.expense),
        formatCurrency(c.income - c.expense),
      ]);

      autoTable(doc, {
        head: [["Kategori", "Pendapatan", "Pengeluaran", "Net"]],
        body: catTableData,
        startY: 22,
        styles: { fontSize: 9, cellPadding: 4 },
        headStyles: { fillColor: [30, 41, 59], textColor: [255, 255, 255], fontStyle: "bold" },
        alternateRowStyles: { fillColor: [248, 250, 252] },
        columnStyles: {
          0: { cellWidth: 80 },
          1: { cellWidth: 60, halign: "right" },
          2: { cellWidth: 60, halign: "right" },
          3: { cellWidth: 60, halign: "right" },
        },
      });

      // Footer on each page
      const pageCount = doc.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setTextColor(148, 163, 184);
        doc.setFontSize(8);
        doc.setFont("helvetica", "normal");
        doc.text(`PadelFin - Sistem Manajemen Keuangan Padel | Halaman ${i} dari ${pageCount}`, 14, 200);
        doc.text(`© ${new Date().getFullYear()} PadelFin`, 250, 200);
      }

      doc.save(`Laporan_Keuangan_Padel_${startDate}_${endDate}.pdf`);
    } catch (e) {
      console.error("Export PDF error:", e);
    } finally {
      setExporting(null);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Laporan Keuangan</h1>
          <p className="text-slate-500 text-sm mt-1">Analisis dan unduh laporan keuangan padel</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={exportExcel}
            disabled={!data || loading || exporting !== null}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2.5 rounded-xl font-medium shadow-lg shadow-green-600/25 transition disabled:opacity-50 text-sm"
          >
            {exporting === "excel" ? (
              <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
            ) : (
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            )}
            Excel
          </button>
          <button
            onClick={exportPDF}
            disabled={!data || loading || exporting !== null}
            className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2.5 rounded-xl font-medium shadow-lg shadow-red-600/25 transition disabled:opacity-50 text-sm"
          >
            {exporting === "pdf" ? (
              <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /></svg>
            ) : (
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            )}
            PDF
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm">
        <h3 className="text-sm font-semibold text-slate-700 mb-3">Filter Periode</h3>
        <div className="flex flex-col sm:flex-row gap-3 items-end">
          <div className="flex-1">
            <label className="block text-xs text-slate-500 mb-1.5">Tanggal Mulai</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400"
            />
          </div>
          <div className="flex-1">
            <label className="block text-xs text-slate-500 mb-1.5">Tanggal Selesai</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400"
            />
          </div>
          <div className="flex gap-2">
            {[
              { label: "Bulan Ini", onClick: () => { const d = new Date(); setStartDate(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-01`); setEndDate(d.toISOString().slice(0,10)); } },
              { label: "3 Bulan", onClick: () => { const d = new Date(); const s = new Date(d); s.setMonth(s.getMonth()-3); setStartDate(s.toISOString().slice(0,10)); setEndDate(d.toISOString().slice(0,10)); } },
              { label: "Tahun Ini", onClick: () => { const d = new Date(); setStartDate(`${d.getFullYear()}-01-01`); setEndDate(d.toISOString().slice(0,10)); } },
            ].map((btn) => (
              <button key={btn.label} onClick={btn.onClick} className="px-3 py-2.5 text-xs text-emerald-600 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl transition whitespace-nowrap">
                {btn.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-40">
          <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
        </div>
      ) : (
        <>
          {/* Summary Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { label: "Total Pendapatan", value: formatCurrency(data?.summary.totalIncome || 0), color: "emerald", icon: "📈" },
              { label: "Total Pengeluaran", value: formatCurrency(data?.summary.totalExpense || 0), color: "red", icon: "📉" },
              { label: "Laba Bersih", value: formatCurrency(data?.summary.netProfit || 0), color: "blue", icon: "💰" },
              { label: "Total Transaksi", value: `${data?.summary.count || 0} transaksi`, color: "purple", icon: "📋" },
            ].map((c) => (
              <div key={c.label} className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm">
                <div className="text-2xl mb-2">{c.icon}</div>
                <p className="text-xl font-bold text-slate-800">{c.value}</p>
                <p className="text-xs text-slate-500 mt-1">{c.label}</p>
              </div>
            ))}
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Daily Trend */}
            <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm">
              <h3 className="font-semibold text-slate-700 mb-4">Tren Harian</h3>
              {dailyData.length > 0 ? (
                <ResponsiveContainer width="100%" height={220}>
                  <LineChart data={dailyData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#94a3b8" }} tickFormatter={(v) => v.slice(5)} />
                    <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} tickFormatter={(v) => `${(v/1000000).toFixed(0)}jt`} />
                    <Tooltip formatter={(v: unknown) => formatCurrency(Number(v))} contentStyle={{ borderRadius: 12, border: "none", boxShadow: "0 4px 24px rgba(0,0,0,0.1)" }} />
                    <Legend />
                    <Line type="monotone" dataKey="income" name="Pendapatan" stroke="#10B981" strokeWidth={2} dot={{ r: 3 }} />
                    <Line type="monotone" dataKey="expense" name="Pengeluaran" stroke="#F87171" strokeWidth={2} dot={{ r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-44 text-slate-400 text-sm">Belum ada data</div>
              )}
            </div>

            {/* Category Bar */}
            <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm">
              <h3 className="font-semibold text-slate-700 mb-4">Per Kategori</h3>
              {categoryData.length > 0 ? (
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={categoryData} layout="vertical" barSize={10}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                    <XAxis type="number" tick={{ fontSize: 10, fill: "#94a3b8" }} tickFormatter={(v) => `${(v/1000000).toFixed(0)}jt`} />
                    <YAxis type="category" dataKey="name" tick={{ fontSize: 9, fill: "#94a3b8" }} width={90} />
                    <Tooltip formatter={(v: unknown) => formatCurrency(Number(v))} contentStyle={{ borderRadius: 12, border: "none", boxShadow: "0 4px 24px rgba(0,0,0,0.1)" }} />
                    <Bar dataKey="income" name="Pendapatan" fill="#10B981" radius={[0, 4, 4, 0]} />
                    <Bar dataKey="expense" name="Pengeluaran" fill="#F87171" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-44 text-slate-400 text-sm">Belum ada data</div>
              )}
            </div>

            {/* Income Pie */}
            <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm">
              <h3 className="font-semibold text-slate-700 mb-4">Komposisi Pendapatan</h3>
              {incomePieData.length > 0 ? (
                <div className="flex gap-4">
                  <ResponsiveContainer width="50%" height={200}>
                    <PieChart>
                      <Pie data={incomePieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" paddingAngle={2}>
                        {incomePieData.map((e, i) => <Cell key={i} fill={e.color} />)}
                      </Pie>
                      <Tooltip formatter={(v: unknown) => formatCurrency(Number(v))} contentStyle={{ borderRadius: 12, border: "none" }} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex-1 space-y-2 py-2">
                    {incomePieData.map((item, i) => (
                      <div key={i} className="flex items-center justify-between text-xs gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }} />
                          <span className="text-slate-600 truncate">{item.name}</span>
                        </div>
                        <span className="font-semibold text-slate-700 flex-shrink-0">{formatCurrency(item.value)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-44 text-slate-400 text-sm">Belum ada data</div>
              )}
            </div>

            {/* Expense Pie */}
            <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm">
              <h3 className="font-semibold text-slate-700 mb-4">Komposisi Pengeluaran</h3>
              {expensePieData.length > 0 ? (
                <div className="flex gap-4">
                  <ResponsiveContainer width="50%" height={200}>
                    <PieChart>
                      <Pie data={expensePieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" paddingAngle={2}>
                        {expensePieData.map((e, i) => <Cell key={i} fill={e.color} />)}
                      </Pie>
                      <Tooltip formatter={(v: unknown) => formatCurrency(Number(v))} contentStyle={{ borderRadius: 12, border: "none" }} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex-1 space-y-2 py-2">
                    {expensePieData.map((item, i) => (
                      <div key={i} className="flex items-center justify-between text-xs gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }} />
                          <span className="text-slate-600 truncate">{item.name}</span>
                        </div>
                        <span className="font-semibold text-slate-700 flex-shrink-0">{formatCurrency(item.value)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-44 text-slate-400 text-sm">Belum ada data</div>
              )}
            </div>
          </div>

          {/* Transaction Detail Table */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-semibold text-slate-700">Detail Transaksi ({data?.summary.count || 0})</h3>
              <div className="flex gap-2">
                <span className="text-xs text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">
                  {data?.transactions.filter(t => t.type === "income").length || 0} pendapatan
                </span>
                <span className="text-xs text-red-500 bg-red-50 px-2 py-1 rounded-lg">
                  {data?.transactions.filter(t => t.type === "expense").length || 0} pengeluaran
                </span>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-slate-50">
                    <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Tanggal</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Tipe</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Kategori</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Deskripsi</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Member</th>
                    <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Pembayaran</th>
                    <th className="text-right px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Jumlah</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {data?.transactions.length === 0 && (
                    <tr><td colSpan={7} className="text-center py-12 text-slate-400">Tidak ada transaksi dalam periode ini</td></tr>
                  )}
                  {data?.transactions.map((t) => (
                    <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-5 py-3.5 text-sm text-slate-600 whitespace-nowrap">
                        {new Date(t.transactionDate).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" })}
                      </td>
                      <td className="px-5 py-3.5">
                        <span className={`text-xs font-semibold px-2 py-1 rounded-lg ${t.type === "income" ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-600"}`}>
                          {t.type === "income" ? "Pendapatan" : "Pengeluaran"}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-sm text-slate-600">{categoryLabels[t.category] || t.category}</td>
                      <td className="px-5 py-3.5 text-sm text-slate-700 font-medium max-w-[200px] truncate">{t.description}</td>
                      <td className="px-5 py-3.5 text-sm text-slate-500">{t.memberName || "-"}</td>
                      <td className="px-5 py-3.5 text-sm text-slate-500">{paymentMethodLabels[t.paymentMethod] || t.paymentMethod}</td>
                      <td className="px-5 py-3.5 text-right">
                        <span className={`text-sm font-bold ${t.type === "income" ? "text-emerald-600" : "text-red-500"}`}>
                          {t.type === "income" ? "+" : "-"}{formatCurrency(parseFloat(t.amount))}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
                {data && data.transactions.length > 0 && (
                  <tfoot className="bg-slate-50 border-t-2 border-slate-200">
                    <tr>
                      <td colSpan={5} className="px-5 py-3 text-sm font-semibold text-slate-700">Total</td>
                      <td className="px-5 py-3 text-right text-sm font-bold text-emerald-600">+{formatCurrency(data.summary.totalIncome)}</td>
                      <td className="px-5 py-3 text-right text-sm font-bold text-red-500">-{formatCurrency(data.summary.totalExpense)}</td>
                    </tr>
                    <tr>
                      <td colSpan={5} className="px-5 py-3 text-sm font-semibold text-slate-700">Laba Bersih</td>
                      <td colSpan={2} className={`px-5 py-3 text-right text-sm font-bold ${data.summary.netProfit >= 0 ? "text-blue-600" : "text-orange-500"}`}>
                        {formatCurrency(data.summary.netProfit)}
                      </td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
