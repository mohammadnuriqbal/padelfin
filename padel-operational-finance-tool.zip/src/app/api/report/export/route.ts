import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { transactions } from "@/db/schema";
import { and, gte, lte, desc } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { categoryLabels, paymentMethodLabels } from "@/lib/utils";

export async function GET(request: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const startDate = searchParams.get("startDate") || "";
  const endDate = searchParams.get("endDate") || "";
  const format = searchParams.get("format") || "json";

  const conditions = [];
  if (startDate) conditions.push(gte(transactions.transactionDate, startDate));
  if (endDate) conditions.push(lte(transactions.transactionDate, endDate));

  const data = await db
    .select()
    .from(transactions)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(transactions.transactionDate));

  if (format === "json") {
    const totalIncome = data
      .filter((t) => t.type === "income")
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);
    const totalExpense = data
      .filter((t) => t.type === "expense")
      .reduce((sum, t) => sum + parseFloat(t.amount), 0);

    return NextResponse.json({
      transactions: data,
      summary: {
        totalIncome,
        totalExpense,
        netProfit: totalIncome - totalExpense,
        count: data.length,
      },
      period: { startDate, endDate },
    });
  }

  return NextResponse.json({ transactions: data });
}
