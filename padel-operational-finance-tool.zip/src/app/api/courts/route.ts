import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { courts } from "@/db/schema";
import { asc } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const data = await db.select().from(courts).orderBy(asc(courts.courtNumber));
  return NextResponse.json({ courts: data });
}

export async function POST(request: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await request.json();
    const { name, courtNumber, hourlyRate, status, notes } = body;

    const [newCourt] = await db
      .insert(courts)
      .values({
        name,
        courtNumber: parseInt(courtNumber),
        hourlyRate: hourlyRate.toString(),
        status: status || "active",
        notes: notes || null,
      })
      .returning();

    return NextResponse.json({ court: newCourt }, { status: 201 });
  } catch (error) {
    console.error("Create court error:", error);
    return NextResponse.json({ error: "Gagal menambah lapangan" }, { status: 500 });
  }
}
