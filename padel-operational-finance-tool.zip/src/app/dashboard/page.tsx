"use client";

import { useEffect, useState } from "react";
import { formatCurrency, categoryLabels, categoryColors } from "@/lib/utils";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

interface Summary {
  totalIncome: number;
  totalExpense: number;
  netProfit: number;
  incomeCount: number;
  expenseCount: number;
}

interface DashboardData {
  summary: Summary;
  categoryBreakdown: Array<{ category: string; type: string; total: string; count: number }>;
  dailyTrend: Array<{ date: string; type: string; total: string }>;
  monthlyTrend: Array<{ month: string; type: string; total: string }>;
  recentTransactions: Array<{
    id: number;
    type: string;
    category: string;
    description: string;
    amount: string;
    transactionDate: string;
    paymentMethod: string;
  }>;
}

const MONTHS_ID = [
  "Jan", "Feb", "Mar", "Apr", "Mei", "Jun",
  "Jul", "Agu", "Sep", "Okt", "Nov", "Des",
];

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedMonth, setSelectedMonth] = useState(
    new Date().toISOString().slice(0, 7)
  );

  const fetchDashboard = async (month: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/dashboard?month=${month}`);
      const d = await res.json();
      setData(d);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboard(selectedMonth);
  }, [selectedMonth]);

  // Process monthly trend for chart
  const monthlyChartData = (() => {
    if (!data) return [];
    const map: Record<string, { month: string; income: number; expense: number }> = {};
    data.monthlyTrend.forEach((t) => {
      if (!map[t.month]) {
        const [, m] = t.month.split("-");
        map[t.month] = { month: MONTHS_ID[parseInt(m) - 1], income: 0, expense: 0 };
      }
      if (t.type === "income") map[t.month].income = parseFloat(t.total);
      if (t.type === "expense") map[t.month].expense = parseFloat(t.total);
    });
    return Object.values(map);
  })();

  // Process category breakdown for pie chart
  const incomePieData = data?.categoryBreakdown
    .filter((c) => c.type === "income")
    .map((c) => ({ name: categoryLabels[c.category] || c.category, value: parseFloat(c.total), color: categoryColors[c.category] || "#10B981" })) || [];

  const expensePieData = data?.categoryBreakdown
    .filter((c) => c.type === "expense")
    .map((c) => ({ name: categoryLabels[c.category] || c.category, value: parseFloat(c.total), color: categoryColors[c.category] || "#EF4444" })) || [];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-slate-500 text-sm">Memuat dashboard...</p>
        </div>
      </div>
    );
  }

  const summary = data?.summary;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Ringkasan Keuangan</h1>
          <p className="text-slate-500 text-sm mt-1">Pantau performa keuangan padel Anda</p>
        </div>
        <div>
          <input
            type="month"
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700 bg-white shadow-sm focus:outline-none focus:ring-2 focus:ring-emerald-400"
          />
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard
          title="Total Pendapatan"
          value={formatCurrency(summary?.totalIncome || 0)}
          sub={`${summary?.incomeCount || 0} transaksi`}
          icon={<svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
          color="emerald"
          trend="up"
        />
        <StatCard
          title="Total Pengeluaran"
          value={formatCurrency(summary?.totalExpense || 0)}
          sub={`${summary?.expenseCount || 0} transaksi`}
          icon={<svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" /></svg>}
          color="red"
          trend="down"
        />
        <StatCard
          title="Laba Bersih"
          value={formatCurrency(summary?.netProfit || 0)}
          sub={(summary?.netProfit || 0) >= 0 ? "Surplus" : "Defisit"}
          icon={<svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>}
          color={(summary?.netProfit || 0) >= 0 ? "blue" : "orange"}
          trend={(summary?.netProfit || 0) >= 0 ? "up" : "down"}
        />
        <StatCard
          title="Margin"
          value={
            summary?.totalIncome
              ? `${((summary.netProfit / summary.totalIncome) * 100).toFixed(1)}%`
              : "0%"
          }
          sub="Dari pendapatan"
          icon={<svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>}
          color="purple"
          trend="up"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Monthly Trend */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-100 p-5">
          <h3 className="font-semibold text-slate-700 mb-4">Tren Bulanan {selectedMonth.slice(0, 4)}</h3>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={monthlyChartData} barSize={14}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#94a3b8" }} />
              <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} tickFormatter={(v) => `${(v / 1000000).toFixed(0)}jt`} />
              <Tooltip
                formatter={(v: unknown) => formatCurrency(Number(v))}
                contentStyle={{ borderRadius: 12, border: "none", boxShadow: "0 4px 24px rgba(0,0,0,0.1)" }}
              />
              <Legend />
              <Bar dataKey="income" name="Pendapatan" fill="#10B981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="expense" name="Pengeluaran" fill="#F87171" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Income Pie */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5">
          <h3 className="font-semibold text-slate-700 mb-4">Komposisi Pendapatan</h3>
          {incomePieData.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={incomePieData} cx="50%" cy="50%" innerRadius={45} outerRadius={75} dataKey="value" paddingAngle={2}>
                    {incomePieData.map((entry, idx) => (
                      <Cell key={idx} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v: unknown) => formatCurrency(Number(v))} contentStyle={{ borderRadius: 12, border: "none", boxShadow: "0 4px 24px rgba(0,0,0,0.1)" }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-2 mt-2">
                {incomePieData.slice(0, 4).map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }} />
                      <span className="text-slate-600 truncate max-w-[100px]">{item.name}</span>
                    </div>
                    <span className="font-medium text-slate-700">{formatCurrency(item.value)}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-40 text-slate-400 text-sm">
              Belum ada data
            </div>
          )}
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-semibold text-slate-700">Transaksi Terbaru</h3>
          <a href="/dashboard/transactions" className="text-xs text-emerald-600 hover:text-emerald-700 font-medium">
            Lihat Semua →
          </a>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50">
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Tanggal</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Deskripsi</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Kategori</th>
                <th className="text-right px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Jumlah</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {data?.recentTransactions.length === 0 && (
                <tr><td colSpan={4} className="text-center py-8 text-slate-400 text-sm">Belum ada transaksi</td></tr>
              )}
              {data?.recentTransactions.map((t) => (
                <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-5 py-3.5 text-sm text-slate-600 whitespace-nowrap">
                    {new Date(t.transactionDate).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" })}
                  </td>
                  <td className="px-5 py-3.5 text-sm text-slate-700 font-medium max-w-[200px] truncate">
                    {t.description}
                  </td>
                  <td className="px-5 py-3.5">
                    <span className="inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-100 text-slate-600">
                      {categoryLabels[t.category] || t.category}
                    </span>
                  </td>
                  <td className="px-5 py-3.5 text-right">
                    <span className={`text-sm font-semibold ${t.type === "income" ? "text-emerald-600" : "text-red-500"}`}>
                      {t.type === "income" ? "+" : "-"}{formatCurrency(parseFloat(t.amount))}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatCard({
  title,
  value,
  sub,
  icon,
  color,
  trend,
}: {
  title: string;
  value: string;
  sub: string;
  icon: React.ReactNode;
  color: string;
  trend: "up" | "down";
}) {
  const colors: Record<string, string> = {
    emerald: "from-emerald-50 to-emerald-100 text-emerald-600 border-emerald-100",
    red: "from-red-50 to-red-100 text-red-600 border-red-100",
    blue: "from-blue-50 to-blue-100 text-blue-600 border-blue-100",
    purple: "from-purple-50 to-purple-100 text-purple-600 border-purple-100",
    orange: "from-orange-50 to-orange-100 text-orange-600 border-orange-100",
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${colors[color]} flex items-center justify-center border`}>
          {icon}
        </div>
        <span className={`text-xs font-medium px-2 py-1 rounded-lg ${trend === "up" ? "bg-emerald-50 text-emerald-600" : "bg-red-50 text-red-500"}`}>
          {trend === "up" ? "▲" : "▼"}
        </span>
      </div>
      <p className="text-2xl font-bold text-slate-800 mt-2 leading-none">{value}</p>
      <p className="text-sm text-slate-500 mt-1.5">{title}</p>
      <p className="text-xs text-slate-400 mt-0.5">{sub}</p>
    </div>
  );
}
