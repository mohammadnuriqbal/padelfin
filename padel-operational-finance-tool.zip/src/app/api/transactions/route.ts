import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { transactions } from "@/db/schema";
import { desc, eq, and, gte, lte, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET(request: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const startDate = searchParams.get("startDate");
  const endDate = searchParams.get("endDate");
  const type = searchParams.get("type");
  const category = searchParams.get("category");
  const limit = parseInt(searchParams.get("limit") || "100");
  const offset = parseInt(searchParams.get("offset") || "0");

  const conditions = [];
  if (startDate) conditions.push(gte(transactions.transactionDate, startDate));
  if (endDate) conditions.push(lte(transactions.transactionDate, endDate));
  if (type && (type === "income" || type === "expense")) {
    conditions.push(eq(transactions.type, type));
  }

  const query = db
    .select()
    .from(transactions)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(desc(transactions.transactionDate), desc(transactions.createdAt))
    .limit(limit)
    .offset(offset);

  const data = await query;

  // Filter by category if provided (post-fetch for enum safety)
  const filtered = category ? data.filter((t) => t.category === category) : data;

  return NextResponse.json({ transactions: filtered });
}

export async function POST(request: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await request.json();
    const {
      type,
      category,
      description,
      amount,
      paymentMethod,
      transactionDate,
      courtNumber,
      memberName,
      notes,
    } = body;

    if (!type || !category || !description || !amount || !transactionDate) {
      return NextResponse.json(
        { error: "Field yang diperlukan tidak lengkap" },
        { status: 400 }
      );
    }

    const [newTransaction] = await db
      .insert(transactions)
      .values({
        type,
        category,
        description,
        amount: amount.toString(),
        paymentMethod: paymentMethod || "cash",
        transactionDate,
        courtNumber: courtNumber || null,
        memberName: memberName || null,
        notes: notes || null,
        createdBy: session.userId,
      })
      .returning();

    return NextResponse.json({ transaction: newTransaction }, { status: 201 });
  } catch (error) {
    console.error("Create transaction error:", error);
    return NextResponse.json(
      { error: "Gagal membuat transaksi" },
      { status: 500 }
    );
  }
}
