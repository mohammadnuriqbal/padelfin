import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { transactions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const { id } = await params;
    const body = await request.json();
    const {
      type,
      category,
      description,
      amount,
      paymentMethod,
      transactionDate,
      courtNumber,
      memberName,
      notes,
    } = body;

    const [updated] = await db
      .update(transactions)
      .set({
        type,
        category,
        description,
        amount: amount.toString(),
        paymentMethod,
        transactionDate,
        courtNumber: courtNumber || null,
        memberName: memberName || null,
        notes: notes || null,
        updatedAt: new Date(),
      })
      .where(eq(transactions.id, parseInt(id)))
      .returning();

    if (!updated) {
      return NextResponse.json({ error: "Transaksi tidak ditemukan" }, { status: 404 });
    }

    return NextResponse.json({ transaction: updated });
  } catch (error) {
    console.error("Update transaction error:", error);
    return NextResponse.json({ error: "Gagal memperbarui transaksi" }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const { id } = await params;
    await db.delete(transactions).where(eq(transactions.id, parseInt(id)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete transaction error:", error);
    return NextResponse.json({ error: "Gagal menghapus transaksi" }, { status: 500 });
  }
}
