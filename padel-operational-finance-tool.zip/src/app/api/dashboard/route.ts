import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { transactions } from "@/db/schema";
import { eq, and, gte, lte, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET(request: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const month = searchParams.get("month") || new Date().toISOString().slice(0, 7);
  const [year, monthNum] = month.split("-");
  const startDate = `${year}-${monthNum}-01`;
  const lastDay = new Date(parseInt(year), parseInt(monthNum), 0).getDate();
  const endDate = `${year}-${monthNum}-${lastDay.toString().padStart(2, "0")}`;

  // Total income & expense for selected month
  const summary = await db
    .select({
      type: transactions.type,
      total: sql<string>`SUM(${transactions.amount})`,
      count: sql<number>`COUNT(*)`,
    })
    .from(transactions)
    .where(
      and(
        gte(transactions.transactionDate, startDate),
        lte(transactions.transactionDate, endDate)
      )
    )
    .groupBy(transactions.type);

  // Category breakdown
  const categoryBreakdown = await db
    .select({
      category: transactions.category,
      type: transactions.type,
      total: sql<string>`SUM(${transactions.amount})`,
      count: sql<number>`COUNT(*)`,
    })
    .from(transactions)
    .where(
      and(
        gte(transactions.transactionDate, startDate),
        lte(transactions.transactionDate, endDate)
      )
    )
    .groupBy(transactions.category, transactions.type);

  // Daily trend for the month
  const dailyTrend = await db
    .select({
      date: transactions.transactionDate,
      type: transactions.type,
      total: sql<string>`SUM(${transactions.amount})`,
    })
    .from(transactions)
    .where(
      and(
        gte(transactions.transactionDate, startDate),
        lte(transactions.transactionDate, endDate)
      )
    )
    .groupBy(transactions.transactionDate, transactions.type)
    .orderBy(transactions.transactionDate);

  // Monthly trend for the year
  const monthlyTrend = await db
    .select({
      month: sql<string>`TO_CHAR(${transactions.transactionDate}::date, 'YYYY-MM')`,
      type: transactions.type,
      total: sql<string>`SUM(${transactions.amount})`,
    })
    .from(transactions)
    .where(
      and(
        gte(transactions.transactionDate, `${year}-01-01`),
        lte(transactions.transactionDate, `${year}-12-31`)
      )
    )
    .groupBy(
      sql`TO_CHAR(${transactions.transactionDate}::date, 'YYYY-MM')`,
      transactions.type
    )
    .orderBy(sql`TO_CHAR(${transactions.transactionDate}::date, 'YYYY-MM')`);

  // Recent transactions
  const recentTransactions = await db
    .select()
    .from(transactions)
    .orderBy(sql`${transactions.transactionDate} DESC`, sql`${transactions.createdAt} DESC`)
    .limit(10);

  const totalIncome = summary.find((s) => s.type === "income")?.total || "0";
  const totalExpense = summary.find((s) => s.type === "expense")?.total || "0";
  const netProfit = parseFloat(totalIncome) - parseFloat(totalExpense);

  return NextResponse.json({
    summary: {
      totalIncome: parseFloat(totalIncome),
      totalExpense: parseFloat(totalExpense),
      netProfit,
      incomeCount: summary.find((s) => s.type === "income")?.count || 0,
      expenseCount: summary.find((s) => s.type === "expense")?.count || 0,
    },
    categoryBreakdown,
    dailyTrend,
    monthlyTrend,
    recentTransactions,
  });
}
