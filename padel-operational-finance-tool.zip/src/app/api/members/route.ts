import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { members } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function GET() {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const data = await db.select().from(members).orderBy(desc(members.createdAt));
  return NextResponse.json({ members: data });
}

export async function POST(request: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await request.json();
    const { name, phone, email, membershipType, joinDate, expiryDate, notes } = body;

    if (!name || !joinDate) {
      return NextResponse.json({ error: "Nama dan tanggal bergabung diperlukan" }, { status: 400 });
    }

    const [newMember] = await db
      .insert(members)
      .values({
        name,
        phone: phone || null,
        email: email || null,
        membershipType: membershipType || "regular",
        joinDate,
        expiryDate: expiryDate || null,
        notes: notes || null,
      })
      .returning();

    return NextResponse.json({ member: newMember }, { status: 201 });
  } catch (error) {
    console.error("Create member error:", error);
    return NextResponse.json({ error: "Gagal menambah member" }, { status: 500 });
  }
}
