import {
  pgTable,
  serial,
  text,
  varchar,
  decimal,
  integer,
  timestamp,
  date,
  boolean,
  pgEnum,
} from "drizzle-orm/pg-core";

// Enums
export const transactionTypeEnum = pgEnum("transaction_type", [
  "income",
  "expense",
]);

export const categoryEnum = pgEnum("category", [
  // Income categories
  "court_rental",
  "membership",
  "coaching",
  "equipment_rental",
  "tournament",
  "cafe_fnb",
  "other_income",
  // Expense categories
  "utilities",
  "staff_salary",
  "maintenance",
  "equipment_purchase",
  "marketing",
  "rent",
  "cleaning",
  "other_expense",
]);

export const paymentMethodEnum = pgEnum("payment_method", [
  "cash",
  "transfer",
  "qris",
  "debit",
  "credit",
]);

export const statusEnum = pgEnum("status", ["active", "inactive"]);

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 50 }).notNull().unique(),
  password: text("password").notNull(),
  fullName: varchar("full_name", { length: 100 }).notNull(),
  role: varchar("role", { length: 20 }).notNull().default("admin"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Transactions table
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  type: transactionTypeEnum("type").notNull(),
  category: categoryEnum("category").notNull(),
  description: text("description").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  paymentMethod: paymentMethodEnum("payment_method").notNull().default("cash"),
  transactionDate: date("transaction_date").notNull(),
  courtNumber: integer("court_number"),
  memberName: varchar("member_name", { length: 100 }),
  notes: text("notes"),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Courts table
export const courts = pgTable("courts", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 50 }).notNull(),
  courtNumber: integer("court_number").notNull().unique(),
  hourlyRate: decimal("hourly_rate", { precision: 10, scale: 2 }).notNull(),
  status: statusEnum("status").notNull().default("active"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Members table
export const members = pgTable("members", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  email: varchar("email", { length: 100 }),
  membershipType: varchar("membership_type", { length: 50 }).notNull().default("regular"),
  joinDate: date("join_date").notNull(),
  expiryDate: date("expiry_date"),
  isActive: boolean("is_active").notNull().default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Expenses recurring table
export const recurringExpenses = pgTable("recurring_expenses", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  category: categoryEnum("category").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  frequency: varchar("frequency", { length: 20 }).notNull().default("monthly"),
  isActive: boolean("is_active").notNull().default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
