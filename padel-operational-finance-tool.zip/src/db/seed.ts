import "dotenv/config";
import { db } from "./index";
import { users, courts, members, transactions } from "./schema";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";

async function seed() {
  console.log("🌱 Seeding database...");

  // Create admin user
  const existingUser = await db.select().from(users).where(eq(users.username, "admin")).limit(1);
  if (existingUser.length === 0) {
    const hashedPassword = await bcrypt.hash("padel001", 12);
    await db.insert(users).values({
      username: "admin",
      password: hashedPassword,
      fullName: "Administrator Padel",
      role: "admin",
    });
    console.log("✅ Admin user created (username: admin, password: padel001)");
  } else {
    console.log("ℹ️  Admin user already exists");
  }

  // Create courts
  const existingCourts = await db.select().from(courts).limit(1);
  if (existingCourts.length === 0) {
    await db.insert(courts).values([
      { name: "Lapangan A", courtNumber: 1, hourlyRate: "150000", status: "active" },
      { name: "Lapangan B", courtNumber: 2, hourlyRate: "150000", status: "active" },
      { name: "Lapangan C (Premium)", courtNumber: 3, hourlyRate: "200000", status: "active" },
      { name: "Lapangan D", courtNumber: 4, hourlyRate: "150000", status: "inactive", notes: "Sedang maintenance" },
    ]);
    console.log("✅ Courts seeded");
  }

  // Create members
  const existingMembers = await db.select().from(members).limit(1);
  if (existingMembers.length === 0) {
    await db.insert(members).values([
      { name: "Budi Santoso", phone: "081234567890", email: "budi@email.com", membershipType: "premium", joinDate: "2024-01-15", expiryDate: "2025-01-15" },
      { name: "Sari Dewi", phone: "082345678901", email: "sari@email.com", membershipType: "regular", joinDate: "2024-03-01", expiryDate: "2025-03-01" },
      { name: "Ahmad Fadli", phone: "083456789012", membershipType: "vip", joinDate: "2024-02-10", expiryDate: "2025-02-10" },
      { name: "Rina Kusuma", phone: "084567890123", email: "rina@email.com", membershipType: "regular", joinDate: "2024-06-01", expiryDate: "2025-06-01" },
      { name: "Dito Prasetyo", phone: "085678901234", membershipType: "premium", joinDate: "2024-04-20", expiryDate: "2025-04-20" },
    ]);
    console.log("✅ Members seeded");
  }

  // Create sample transactions for current month and previous months
  const existingTx = await db.select().from(transactions).limit(1);
  if (existingTx.length === 0) {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + 1;

    const [adminUser] = await db.select().from(users).where(eq(users.username, "admin")).limit(1);

    const sampleTransactions = [
      // Current month income
      { type: "income" as const, category: "court_rental" as const, description: "Sewa Lapangan A - Budi Santoso", amount: "150000", paymentMethod: "qris" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-01`, courtNumber: 1, memberName: "Budi Santoso", createdBy: adminUser.id },
      { type: "income" as const, category: "court_rental" as const, description: "Sewa Lapangan B - Sari Dewi", amount: "150000", paymentMethod: "cash" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-02`, courtNumber: 2, memberName: "Sari Dewi", createdBy: adminUser.id },
      { type: "income" as const, category: "membership" as const, description: "Perpanjangan Membership Premium - Ahmad Fadli", amount: "500000", paymentMethod: "transfer" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-03`, memberName: "Ahmad Fadli", createdBy: adminUser.id },
      { type: "income" as const, category: "coaching" as const, description: "Pelatihan Privat - Rina Kusuma", amount: "300000", paymentMethod: "cash" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-05`, memberName: "Rina Kusuma", createdBy: adminUser.id },
      { type: "income" as const, category: "court_rental" as const, description: "Sewa Lapangan C - Dito Prasetyo", amount: "200000", paymentMethod: "qris" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-07`, courtNumber: 3, memberName: "Dito Prasetyo", createdBy: adminUser.id },
      { type: "income" as const, category: "cafe_fnb" as const, description: "Penjualan Minuman & Snack", amount: "175000", paymentMethod: "cash" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-08`, createdBy: adminUser.id },
      { type: "income" as const, category: "tournament" as const, description: "Pendaftaran Turnamen Padel Cup", amount: "1500000", paymentMethod: "transfer" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-10`, createdBy: adminUser.id },
      { type: "income" as const, category: "court_rental" as const, description: "Sewa Lapangan A - Umum", amount: "150000", paymentMethod: "cash" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-12`, courtNumber: 1, createdBy: adminUser.id },
      { type: "income" as const, category: "equipment_rental" as const, description: "Sewa Raket x4", amount: "80000", paymentMethod: "cash" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-14`, createdBy: adminUser.id },
      { type: "income" as const, category: "membership" as const, description: "Membership Baru - Pelanggan Baru", amount: "350000", paymentMethod: "qris" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-15`, createdBy: adminUser.id },

      // Current month expenses
      { type: "expense" as const, category: "utilities" as const, description: "Tagihan Listrik Bulanan", amount: "800000", paymentMethod: "transfer" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-05`, createdBy: adminUser.id },
      { type: "expense" as const, category: "staff_salary" as const, description: "Gaji Staff Lapangan", amount: "1500000", paymentMethod: "transfer" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-01`, createdBy: adminUser.id },
      { type: "expense" as const, category: "maintenance" as const, description: "Perbaikan Net Lapangan D", amount: "250000", paymentMethod: "cash" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-08`, createdBy: adminUser.id },
      { type: "expense" as const, category: "cleaning" as const, description: "Jasa Kebersihan", amount: "200000", paymentMethod: "cash" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-10`, createdBy: adminUser.id },
      { type: "expense" as const, category: "marketing" as const, description: "Iklan Instagram & Facebook", amount: "350000", paymentMethod: "transfer" as const, transactionDate: `${year}-${String(month).padStart(2,"0")}-12`, createdBy: adminUser.id },
    ];

    await db.insert(transactions).values(sampleTransactions);

    // Previous month transactions
    const prevMonth = month === 1 ? 12 : month - 1;
    const prevYear = month === 1 ? year - 1 : year;
    const prevMonthStr = `${prevYear}-${String(prevMonth).padStart(2,"0")}`;

    await db.insert(transactions).values([
      { type: "income" as const, category: "court_rental" as const, description: "Sewa Lapangan - Pendapatan Bulan Lalu", amount: "2500000", paymentMethod: "cash" as const, transactionDate: `${prevMonthStr}-15`, createdBy: adminUser.id },
      { type: "income" as const, category: "membership" as const, description: "Membership Bulan Lalu", amount: "1200000", paymentMethod: "transfer" as const, transactionDate: `${prevMonthStr}-10`, createdBy: adminUser.id },
      { type: "income" as const, category: "coaching" as const, description: "Coaching Bulan Lalu", amount: "600000", paymentMethod: "cash" as const, transactionDate: `${prevMonthStr}-20`, createdBy: adminUser.id },
      { type: "expense" as const, category: "rent" as const, description: "Sewa Tempat Bulan Lalu", amount: "3000000", paymentMethod: "transfer" as const, transactionDate: `${prevMonthStr}-01`, createdBy: adminUser.id },
      { type: "expense" as const, category: "utilities" as const, description: "Listrik & Air Bulan Lalu", amount: "850000", paymentMethod: "transfer" as const, transactionDate: `${prevMonthStr}-05`, createdBy: adminUser.id },
      { type: "expense" as const, category: "staff_salary" as const, description: "Gaji Staff Bulan Lalu", amount: "1500000", paymentMethod: "transfer" as const, transactionDate: `${prevMonthStr}-01`, createdBy: adminUser.id },
    ]);

    console.log("✅ Sample transactions seeded");
  }

  console.log("🎉 Seeding complete!");
}

seed().catch(console.error);
