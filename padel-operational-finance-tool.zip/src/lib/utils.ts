export function formatCurrency(amount: number | string): string {
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(num);
}

export function formatDate(dateStr: string | Date): string {
  const d = typeof dateStr === "string" ? new Date(dateStr) : dateStr;
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  }).format(d);
}

export function formatDateShort(dateStr: string | Date): string {
  const d = typeof dateStr === "string" ? new Date(dateStr) : dateStr;
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(d);
}

export const categoryLabels: Record<string, string> = {
  court_rental: "Sewa Lapangan",
  membership: "Membership",
  coaching: "Pelatihan/Coaching",
  equipment_rental: "Sewa Peralatan",
  tournament: "Turnamen",
  cafe_fnb: "Kafe/F&B",
  other_income: "Pendapatan Lainnya",
  utilities: "Listrik & Air",
  staff_salary: "Gaji Karyawan",
  maintenance: "Pemeliharaan",
  equipment_purchase: "Pembelian Peralatan",
  marketing: "Marketing & Promosi",
  rent: "Sewa Tempat",
  cleaning: "Kebersihan",
  other_expense: "Pengeluaran Lainnya",
};

export const paymentMethodLabels: Record<string, string> = {
  cash: "Tunai",
  transfer: "Transfer Bank",
  qris: "QRIS",
  debit: "Kartu Debit",
  credit: "Kartu Kredit",
};

export const categoryColors: Record<string, string> = {
  court_rental: "#10B981",
  membership: "#3B82F6",
  coaching: "#8B5CF6",
  equipment_rental: "#F59E0B",
  tournament: "#EF4444",
  cafe_fnb: "#EC4899",
  other_income: "#6B7280",
  utilities: "#F97316",
  staff_salary: "#EF4444",
  maintenance: "#84CC16",
  equipment_purchase: "#06B6D4",
  marketing: "#F59E0B",
  rent: "#6366F1",
  cleaning: "#14B8A6",
  other_expense: "#9CA3AF",
};
