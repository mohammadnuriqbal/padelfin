import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { members } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSession } from "@/lib/auth";

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const { id } = await params;
    const body = await request.json();
    const { name, phone, email, membershipType, joinDate, expiryDate, isActive, notes } = body;

    const [updated] = await db
      .update(members)
      .set({
        name,
        phone: phone || null,
        email: email || null,
        membershipType,
        joinDate,
        expiryDate: expiryDate || null,
        isActive,
        notes: notes || null,
      })
      .where(eq(members.id, parseInt(id)))
      .returning();

    return NextResponse.json({ member: updated });
  } catch (error) {
    console.error("Update member error:", error);
    return NextResponse.json({ error: "Gagal memperbarui member" }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await getSession();
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const { id } = await params;
    await db.delete(members).where(eq(members.id, parseInt(id)));
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete member error:", error);
    return NextResponse.json({ error: "Gagal menghapus member" }, { status: 500 });
  }
}
